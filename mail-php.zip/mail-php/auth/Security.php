<?php
/**
 * Security.php — Central security helpers
 * CSRF tokens, rate limiting, input sanitisation, security headers
 */

class Security {

    // ── CSRF ──────────────────────────────────────────────────────

    /** Generate (or reuse) a per-session CSRF token */
    public static function csrfToken(): string {
        if (session_status() === PHP_SESSION_NONE) self::startSecureSession();
        if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf_token'];
    }

    /** Output a hidden CSRF input field */
    public static function csrfField(): string {
        return '<input type="hidden" name="csrf_token" value="' . self::csrfToken() . '">';
    }

    /** Verify CSRF token from POST or JSON body — dies with 403 on failure */
    public static function verifyCsrf(): void {
        $token = $_POST['csrf_token']
            ?? (json_decode(file_get_contents('php://input'), true)['csrf_token'] ?? '');
        if (!$token || !hash_equals(self::csrfToken(), $token)) {
            http_response_code(403);
            // Return JSON for API calls, HTML for form posts
            if (!empty($_SERVER['HTTP_ACCEPT']) && strpos($_SERVER['HTTP_ACCEPT'], 'application/json') !== false) {
                header('Content-Type: application/json');
                echo json_encode(['error' => 'Invalid CSRF token. Refresh the page and try again.']);
            } else {
                echo '<!DOCTYPE html><html><body style="font-family:sans-serif;background:#0d0d14;color:#f87171;padding:2rem">
                    <h2>403 — Request Blocked</h2><p>Invalid security token. <a href="javascript:history.back()" style="color:#d4a843">Go back</a> and try again.</p>
                    </body></html>';
            }
            exit;
        }
    }

    // ── Rate limiting (file-based, no Redis needed) ───────────────

    private static function rateLimitFile(string $key): string {
        $safe = preg_replace('/[^a-z0-9_]/', '_', strtolower($key));
        $dir  = __DIR__ . '/../data/ratelimit';
        if (!is_dir($dir)) @mkdir($dir, 0700, true);
        return $dir . '/' . $safe . '.json';
    }

    /**
     * Check rate limit. Returns true if allowed, false if blocked.
     * $maxAttempts in $windowSeconds. Lockout for $lockoutSeconds after breach.
     */
    public static function rateLimit(string $key, int $maxAttempts = 5, int $windowSeconds = 60, int $lockoutSeconds = 300): bool {
        $file = self::rateLimitFile($key);
        $data = file_exists($file) ? (json_decode(file_get_contents($file), true) ?? []) : [];

        $now = time();

        // Check if currently locked out
        if (!empty($data['locked_until']) && $now < $data['locked_until']) {
            return false;
        }

        // Clean old attempts outside window
        $data['attempts'] = array_values(array_filter($data['attempts'] ?? [], function($t) use ($now, $windowSeconds) { return ($now - $t) < $windowSeconds; }));

        if (count($data['attempts']) >= $maxAttempts) {
            $data['locked_until'] = $now + $lockoutSeconds;
            $data['attempts'] = [];
            file_put_contents($file, json_encode($data));
            return false;
        }

        $data['attempts'][] = $now;
        unset($data['locked_until']);
        file_put_contents($file, json_encode($data));
        return true;
    }

    /** Clear rate limit record on successful auth */
    public static function rateLimitClear(string $key): void {
        $file = self::rateLimitFile($key);
        if (file_exists($file)) @unlink($file);
    }

    /** Remaining lockout seconds (0 if not locked) */
    public static function rateLimitLockedFor(string $key): int {
        $file = self::rateLimitFile($key);
        if (!file_exists($file)) return 0;
        $data = json_decode(file_get_contents($file), true) ?? [];
        if (!empty($data['locked_until']) && time() < $data['locked_until']) {
            return $data['locked_until'] - time();
        }
        return 0;
    }

    // ── Security headers ──────────────────────────────────────────

    public static function sendHeaders(bool $isApi = false): void {
        // Prevent source map discovery
        header('X-SourceMap: none');
        header('X-Frame-Options: DENY');
        header('X-Content-Type-Options: nosniff');
        header('X-XSS-Protection: 1; mode=block');
        header('Referrer-Policy: strict-origin-when-cross-origin');
        header('Permissions-Policy: geolocation=(), microphone=(), camera=()');

        if ($isApi) {
            header('Cache-Control: no-store, no-cache, must-revalidate, private');
        }

        // CSP: allow self + MS Graph + fonts + OpenRouter
        $csp  = "default-src 'self'; ";
        $csp .= "script-src 'self' 'unsafe-inline'; ";  // inline scripts needed for config vars
        $csp .= "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; ";
        $csp .= "font-src 'self' https://fonts.gstatic.com; ";
        $csp .= "connect-src 'self' https://graph.microsoft.com https://login.microsoftonline.com https://openrouter.ai; ";
        $csp .= "img-src 'self' data: https:; ";
        $csp .= "frame-ancestors 'none'; ";
        $csp .= "form-action 'self';";
        header("Content-Security-Policy: {$csp}");
    }

    // ── Input sanitisation helpers ────────────────────────────────

    /** Sanitise a string for safe HTML output (alias for clarity) */
    public static function h(string $s): string {
        return htmlspecialchars($s, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    }

    /** Validate and return a safe email or empty string */
    public static function email(string $s): string {
        $s = trim($s);
        return filter_var($s, FILTER_VALIDATE_EMAIL) ? $s : '';
    }

    /** Sanitise a filename — strip path traversal */
    public static function filename(string $s): string {
        return basename(preg_replace('/[^\w\.\-]/', '_', $s));
    }

    /** Strip header-injection characters from a header value */
    public static function headerValue(string $s): string {
        return preg_replace('/[\r\n\0]/', '', $s);
    }

    // ── Session hardening ─────────────────────────────────────────

    public static function startSecureSession(): void {
        if (session_status() !== PHP_SESSION_NONE) return;
        $secure = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
        ini_set('session.cookie_httponly',  '1');
        ini_set('session.cookie_samesite',  'Lax');
        ini_set('session.use_strict_mode',  '1');
        ini_set('session.use_only_cookies', '1');
        ini_set('session.gc_maxlifetime',   (string)(defined('SESSION_LIFETIME') ? SESSION_LIFETIME : 86400 * 7));
        if ($secure) ini_set('session.cookie_secure', '1');
        session_start();
    }

    /** Regenerate session ID on privilege change (login/logout) */
    public static function regenerateSession(): void {
        if (session_status() === PHP_SESSION_ACTIVE) {
            session_regenerate_id(true);
        }
    }
}
