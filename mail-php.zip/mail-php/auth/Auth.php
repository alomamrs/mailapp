<?php
require_once __DIR__ . '/../config.php';

class Auth {

    private static $colors = [
        '#e63022','#2563eb','#16a34a','#9333ea',
        '#ea580c','#0891b2','#be185d','#ca8a04',
        '#dc2626','#7c3aed','#0d9488','#b45309',
        '#be123c','#1d4ed8','#15803d','#6d28d9',
    ];

    // ── SQLite DB ────────────────────────────────────────────────

    private static ?PDO $db = null;

    public static function db(): PDO {
        if (self::$db) return self::$db;
        $dir = dirname(DB_FILE);
        if (!is_dir($dir)) mkdir($dir, 0750, true);
        $pdo = new PDO('sqlite:' . DB_FILE);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->exec('PRAGMA journal_mode=WAL');   // concurrent reads
        $pdo->exec('PRAGMA synchronous=NORMAL'); // fast writes
        $pdo->exec('
            CREATE TABLE IF NOT EXISTS accounts (
                id             TEXT PRIMARY KEY,
                email          TEXT NOT NULL,
                name           TEXT NOT NULL,
                color          TEXT NOT NULL,
                access_token   TEXT NOT NULL,
                refresh_token  TEXT,
                token_expires  INTEGER NOT NULL,
                created_at     INTEGER NOT NULL DEFAULT (strftime(\'%s\',\'now\')),
                last_seen      INTEGER,
                portal_user    TEXT
            )
        ');
        // Migration: add portal_user column for existing installs
        try { $pdo->exec('ALTER TABLE accounts ADD COLUMN portal_user TEXT'); } catch(Exception $e) {}
        // Migration: drop UNIQUE on email so different users can share same MS account
        // (SQLite can\'t drop constraints, so we recreate if needed — safe to fail)
        try {
            $pdo->exec('CREATE INDEX IF NOT EXISTS idx_email ON accounts(email)');
            $pdo->exec('CREATE INDEX IF NOT EXISTS idx_portal_user ON accounts(portal_user)');
        } catch(Exception $e) {}
        self::$db = $pdo;
        return $pdo;
    }

    // ── HTTP helper ──────────────────────────────────────────────

    public static function post(string $url, array $body): array {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => http_build_query($body),
            CURLOPT_HTTPHEADER     => ['Content-Type: application/x-www-form-urlencoded'],
            CURLOPT_TIMEOUT        => 30,
            CURLOPT_CONNECTTIMEOUT => 15,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_FOLLOWLOCATION => true,
        ]);
        $response = curl_exec($ch);
        $error    = curl_error($ch);
        curl_close($ch);
        if ($error) throw new Exception('cURL error: ' . $error);
        $data = json_decode($response, true);
        if (json_last_error() !== JSON_ERROR_NONE) throw new Exception('Invalid JSON');
        return $data;
    }

    // ── Device code flow ─────────────────────────────────────────

    public static function getDeviceCode(): array {
        $data = self::post(AUTH_URL . '/devicecode', [
            'client_id' => CLIENT_ID,
            'scope'     => SCOPE,
        ]);
        if (isset($data['error'])) throw new Exception($data['error_description'] ?? $data['error']);
        $_SESSION['pending_device_code']     = $data['device_code'];
        $_SESSION['pending_device_code_exp'] = time() + ($data['expires_in'] ?? 900);
        return [
            'user_code'        => $data['user_code'],
            'verification_uri' => $data['verification_uri'],
            'expires_in'       => $data['expires_in'],
            'interval'         => $data['interval'] ?? 5,
        ];
    }

    public static function pollToken(): array {
        if (empty($_SESSION['pending_device_code'])) {
            return ['status' => 'error', 'message' => 'No pending sign-in.'];
        }
        if (time() > ($_SESSION['pending_device_code_exp'] ?? 0)) {
            unset($_SESSION['pending_device_code'], $_SESSION['pending_device_code_exp']);
            return ['status' => 'expired', 'message' => 'Code expired. Please try again.'];
        }
        $data = self::post(AUTH_URL . '/token', [
            'grant_type'  => 'urn:ietf:params:oauth:grant-type:device_code',
            'client_id'   => CLIENT_ID,
            'device_code' => $_SESSION['pending_device_code'],
        ]);
        if (isset($data['access_token'])) {
            unset($_SESSION['pending_device_code'], $_SESSION['pending_device_code_exp']);
            $profile = self::fetchProfile($data['access_token']);
            $id      = $profile['id'] ?? uniqid('acc_');
            $email   = $profile['mail'] ?? $profile['userPrincipalName'] ?? 'unknown@unknown';
            $name    = $profile['displayName'] ?? $email;

            // Assign colour — cycle through palette based on total account count
            $count = self::db()->query('SELECT COUNT(*) FROM accounts')->fetchColumn();
            $existing = self::db()->prepare('SELECT color FROM accounts WHERE id=?');
            $existing->execute([$id]);
            $row   = $existing->fetch(PDO::FETCH_ASSOC);
            $color = $row ? $row['color'] : self::$colors[$count % count(self::$colors)];

            $portalUser = self::portalUser();
            $stmt = self::db()->prepare('
                INSERT INTO accounts (id,email,name,color,access_token,refresh_token,token_expires,last_seen,portal_user)
                VALUES (:id,:email,:name,:color,:at,:rt,:exp,:now,:pu)
                ON CONFLICT(id) DO UPDATE SET
                    name=excluded.name, email=excluded.email,
                    access_token=excluded.access_token,
                    refresh_token=COALESCE(excluded.refresh_token, refresh_token),
                    token_expires=excluded.token_expires,
                    last_seen=excluded.last_seen,
                    portal_user=COALESCE(portal_user, excluded.portal_user)
            ');
            $stmt->execute([
                ':id'    => $id,
                ':email' => $email,
                ':name'  => $name,
                ':color' => $color,
                ':at'    => $data['access_token'],
                ':rt'    => $data['refresh_token'] ?? null,
                ':exp'   => time() + ($data['expires_in'] ?? 3600),
                ':now'   => time(),
                ':pu'    => $portalUser,
            ]);

            $_SESSION['active_account_' . ($portalUser ?? '')] = $id;
            // Also set legacy key for backwards compat
            $_SESSION['active_account'] = $id;
            return ['status' => 'success', 'account' => [
                'id' => $id, 'name' => $name, 'email' => $email, 'color' => $color
            ]];
        }
        $error = $data['error'] ?? 'unknown';
        if ($error === 'authorization_pending') return ['status' => 'pending'];
        if ($error === 'authorization_declined') return ['status' => 'declined', 'message' => 'Login declined.'];
        if ($error === 'expired_token')          return ['status' => 'expired',  'message' => 'Code expired.'];
        return ['status' => 'error', 'message' => $data['error_description'] ?? $error];
    }

    private static function portalUser(): ?string {
        return $_SESSION['portal_user'] ?? null;
    }

    private static function fetchProfile(string $token): array {
        $ch = curl_init(GRAPH_URL . '/me?$select=id,displayName,mail,userPrincipalName');
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER     => ['Authorization: Bearer ' . $token],
            CURLOPT_TIMEOUT        => 10,
        ]);
        $res = curl_exec($ch);
        curl_close($ch);
        return json_decode($res, true) ?? [];
    }

    // ── Account management ───────────────────────────────────────

    public static function getAccounts(): array {
        $pu = self::portalUser();
        // Admins (not impersonating) see all accounts across all users
        if ($pu) {
            require_once __DIR__ . '/Portal.php';
            $isAdmin        = in_array($pu, defined('ADMIN_USERS') ? ADMIN_USERS : [], true);
            $isImpersonating = !empty($_SESSION['impersonating']);
            if ($isAdmin && !$isImpersonating) {
                // Admin sees all — return all accounts with owner label
                return self::db()->query('SELECT id,name,email,color,portal_user FROM accounts ORDER BY portal_user ASC, last_seen DESC')->fetchAll(PDO::FETCH_ASSOC);
            }
        }
        // Regular users (or admin impersonating) — strict isolation
        if (!$pu) return []; // no session = no accounts
        $stmt = self::db()->prepare('SELECT id,name,email,color,portal_user FROM accounts WHERE portal_user=? ORDER BY last_seen DESC, created_at ASC');
        $stmt->execute([$pu]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function getAllAccounts(): array {
        return self::db()->query('SELECT id,name,email,color,portal_user FROM accounts ORDER BY last_seen DESC, created_at ASC')->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function getActiveAccountId(): ?string {
        $pu = self::portalUser();
        $isAdmin = $pu && in_array($pu, defined('ADMIN_USERS') ? ADMIN_USERS : [], true) && empty($_SESSION['impersonating']);
        $sessKey = 'active_account' . ($pu ? '_' . $pu : '');
        $id = $_SESSION[$sessKey] ?? $_SESSION['active_account'] ?? null;
        if ($id) {
            // Admin can activate any account; others restricted to their own
            $stmt = $isAdmin
                ? self::db()->prepare('SELECT id FROM accounts WHERE id=?')
                : self::db()->prepare('SELECT id FROM accounts WHERE id=? AND portal_user=?');
            $args = $isAdmin ? [$id] : [$id, $pu];
            $stmt->execute($args);
            if ($stmt->fetchColumn()) return $id;
        }
        // Fall back to most recently seen
        if ($isAdmin) {
            $stmt = self::db()->query('SELECT id FROM accounts ORDER BY last_seen DESC LIMIT 1');
        } elseif ($pu) {
            $stmt = self::db()->prepare('SELECT id FROM accounts WHERE portal_user=? ORDER BY last_seen DESC, created_at ASC LIMIT 1');
            $stmt->execute([$pu]);
        } else {
            $stmt = self::db()->query('SELECT id FROM accounts ORDER BY last_seen DESC, created_at ASC LIMIT 1');
        }
        $first = $stmt->fetchColumn();
        if ($first) {
            if (session_status() === PHP_SESSION_ACTIVE) $_SESSION[$sessKey] = $first;
            return $first;
        }
        return null;
    }

    public static function switchAccount(string $id): bool {
        $pu = self::portalUser();
        $isAdmin = $pu && in_array($pu, defined('ADMIN_USERS') ? ADMIN_USERS : [], true) && empty($_SESSION['impersonating']);
        $stmt = ($isAdmin || !$pu)
            ? self::db()->prepare('SELECT id FROM accounts WHERE id=?')
            : self::db()->prepare('SELECT id FROM accounts WHERE id=? AND portal_user=?');
        $args = ($isAdmin || !$pu) ? [$id] : [$id, $pu];
        $stmt->execute($args);
        if (!$stmt->fetchColumn()) return false;
        self::db()->prepare('UPDATE accounts SET last_seen=? WHERE id=?')->execute([time(), $id]);
        $sessKey = 'active_account' . ($pu ? '_' . $pu : '');
        if (session_status() === PHP_SESSION_ACTIVE) { $_SESSION[$sessKey] = $id; session_write_close(); }
        return true;
    }

    /**
     * Check the current portal user owns (or is allowed to use) a given account ID.
     * Admins (non-impersonating) may access any account.
     * Returns the account id if allowed, throws 403 if not.
     */
    public static function assertOwnsAccount(string $id): string {
        if (!$id) throw new \Exception('No account ID provided');
        $pu      = self::portalUser();
        $isAdmin = $pu && in_array($pu, defined('ADMIN_USERS') ? ADMIN_USERS : [], true) && empty($_SESSION['impersonating']);
        if ($isAdmin) return $id; // admins can access any account
        $stmt = self::db()->prepare('SELECT id FROM accounts WHERE id=? AND portal_user=?');
        $stmt->execute([$id, $pu]);
        if (!$stmt->fetchColumn()) {
            http_response_code(403);
            header('Content-Type: application/json');
            echo json_encode(['error' => 'Access denied to this account.']);
            exit;
        }
        return $id;
    }

    public static function removeAccount(string $id): void {
        $pu      = self::portalUser();
        $isAdmin = $pu && in_array($pu, defined('ADMIN_USERS') ? ADMIN_USERS : [], true) && empty($_SESSION['impersonating']);
        self::db()->prepare('DELETE FROM accounts WHERE id=?')->execute([$id]);
        $sessKey = 'active_account' . ($pu ? '_' . $pu : '');
        if (($_SESSION[$sessKey] ?? null) === $id) {
            if ($isAdmin) {
                $next = self::db()->query('SELECT id FROM accounts ORDER BY last_seen DESC LIMIT 1')->fetchColumn();
            } elseif ($pu) {
                $stmt = self::db()->prepare('SELECT id FROM accounts WHERE portal_user=? ORDER BY last_seen DESC LIMIT 1');
                $stmt->execute([$pu]);
                $next = $stmt->fetchColumn();
            } else {
                $next = self::db()->query('SELECT id FROM accounts ORDER BY last_seen DESC LIMIT 1')->fetchColumn();
            }
            if (session_status() === PHP_SESSION_ACTIVE) $_SESSION[$sessKey] = $next ?: null;
        }
    }

    public static function isLoggedIn(): bool {
        return self::getActiveAccountId() !== null;
    }

    // ── Token management ─────────────────────────────────────────

    public static function getToken(?string $accountId = null): ?string {
        $id = $accountId ?? self::getActiveAccountId();
        if (!$id) return null;
        $stmt = self::db()->prepare('SELECT * FROM accounts WHERE id=?');
        $stmt->execute([$id]);
        $acc = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$acc) return null;
        if (time() > ($acc['token_expires'] - 120)) {
            if (!self::refreshToken($id)) {
                // Token refresh failed — do NOT delete the account.
                // Could be a transient network error on the server.
                // Return null so the API call fails gracefully; account stays in DB.
                return null;
            }
            $stmt = self::db()->prepare('SELECT * FROM accounts WHERE id=?');
            $stmt->execute([$id]);
            $acc = $stmt->fetch(PDO::FETCH_ASSOC);
        }
        return $acc['access_token'] ?? null;
    }

    private static function refreshToken(string $id): bool {
        $stmt = self::db()->prepare('SELECT * FROM accounts WHERE id=?');
        $stmt->execute([$id]);
        $acc = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$acc || empty($acc['refresh_token'])) return false;
        try {
            $data = self::post(AUTH_URL . '/token', [
                'grant_type'    => 'refresh_token',
                'client_id'     => CLIENT_ID,
                'refresh_token' => $acc['refresh_token'],
                'scope'         => SCOPE,
            ]);
            if (isset($data['access_token'])) {
                self::db()->prepare('
                    UPDATE accounts SET
                        access_token=?, token_expires=?,
                        refresh_token=COALESCE(?,refresh_token)
                    WHERE id=?
                ')->execute([
                    $data['access_token'],
                    time() + ($data['expires_in'] ?? 3600),
                    $data['refresh_token'] ?? null,
                    $id,
                ]);
                return true;
            }
        } catch (Exception $e) {}
        return false;
    }

    public static function logoutAll(): void {
        self::db()->exec('DELETE FROM accounts');
        $_SESSION = [];
        session_destroy();
    }

    // ── Admin helpers ────────────────────────────────────────────

    /** Total account count — O(1) */
    public static function countAccounts(): int {
        return (int) self::db()->query('SELECT COUNT(*) FROM accounts')->fetchColumn();
    }

    /** Search accounts by name or email */
    public static function searchAccounts(string $q, int $limit = 50): array {
        $q    = '%' . $q . '%';
        $stmt = self::db()->prepare('SELECT id,name,email,color FROM accounts WHERE name LIKE ? OR email LIKE ? LIMIT ?');
        $stmt->execute([$q, $q, $limit]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /** Paginated account list */
    public static function getAccountsPaged(int $page = 0, int $per = 50): array {
        $stmt = self::db()->prepare('SELECT id,name,email,color,last_seen FROM accounts ORDER BY last_seen DESC LIMIT ? OFFSET ?');
        $stmt->execute([$per, $page * $per]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
