<?php
require_once __DIR__ . '/../config.php';

/**
 * Encrypted JSON file storage helper
 * Used for rules, summaries, protocol state
 */
class Storage {

    public static function read(string $file): array {
        if (!file_exists($file)) return [];
        $raw = file_get_contents($file);
        if (!$raw) return [];
        $dec = self::decrypt($raw);
        if (!$dec) return [];
        $data = json_decode($dec, true);
        return is_array($data) ? $data : [];
    }

    public static function write(string $file, array $data): void {
        $dir = dirname($file);
        if (!is_dir($dir)) mkdir($dir, 0750, true);
        file_put_contents($file, self::encrypt(json_encode($data, JSON_PRETTY_PRINT)), LOCK_EX);
    }

    public static function encrypt(string $data): string {
        $key = hash('sha256', STORAGE_KEY, true);
        $iv  = random_bytes(16);
        $enc = openssl_encrypt($data, 'AES-256-CBC', $key, 0, $iv);
        return base64_encode($iv . $enc);
    }

    public static function decrypt(string $data): ?string {
        try {
            $raw = base64_decode($data);
            if (strlen($raw) < 16) return null;
            $key = hash('sha256', STORAGE_KEY, true);
            $iv  = substr($raw, 0, 16);
            $enc = substr($raw, 16);
            $dec = openssl_decrypt($enc, 'AES-256-CBC', $key, 0, $iv);
            return $dec !== false ? $dec : null;
        } catch (Exception $e) { return null; }
    }

    public static function log(string $message): void {
        $line = '[' . date('Y-m-d H:i:s') . '] ' . $message . PHP_EOL;
        file_put_contents(PROTOCOL_LOG, $line, FILE_APPEND | LOCK_EX);
        // Keep log under 500 lines
        if (rand(0, 20) === 0) {
            $lines = file(PROTOCOL_LOG);
            if (count($lines) > 500) {
                file_put_contents(PROTOCOL_LOG, implode('', array_slice($lines, -300)));
            }
        }
    }
}
