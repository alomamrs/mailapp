<?php
require_once __DIR__ . '/../config.php';

class Portal {

    private static string $usersFile = '';

    private static function usersFile(): string {
        if (!self::$usersFile) {
            self::$usersFile = __DIR__ . '/../data/portal_users.json';
        }
        return self::$usersFile;
    }

    public static function metaFile(): string {
        return __DIR__ . '/../data/portal_users_meta.json';
    }

    private static function loadMeta(): array {
        $f = self::metaFile();
        return file_exists($f) ? (json_decode(file_get_contents($f), true) ?? []) : [];
    }

    private static function saveMeta(array $meta): bool {
        return file_put_contents(self::metaFile(), json_encode($meta, JSON_PRETTY_PRINT)) !== false;
    }

    private static function loadUsers(): array {
        $f = self::usersFile();

        // First run — seed from PORTAL_USERS in config.php
        if (!file_exists($f)) {
            $seed = defined('PORTAL_USERS') ? PORTAL_USERS : ['admin' => 'admin123'];
            $out  = [];
            foreach ($seed as $u => $p) {
                $out[$u] = (strlen($p) >= 60 && strncmp($p, '$2', 2) === 0)
                    ? $p
                    : password_hash($p, PASSWORD_DEFAULT);
            }
            file_put_contents($f, json_encode($out, JSON_PRETTY_PRINT));
            return $out;
        }

        return json_decode(file_get_contents($f), true) ?? [];
    }

    private static function saveUsers(array $users): bool {
        return file_put_contents(self::usersFile(), json_encode($users, JSON_PRETTY_PRINT)) !== false;
    }

    // ── Auth ─────────────────────────────────────────────────────

    public static function isAuthed(): bool {
        if (empty($_SESSION['portal_user'])) return false;
        $user = $_SESSION['portal_user'];
        // Check expiry
        $meta = self::loadMeta();
        if (isset($meta[$user]['expires_at']) && $meta[$user]['expires_at'] !== null) {
            if (time() > $meta[$user]['expires_at']) {
                self::logout();
                return false;
            }
        }
        return true;
    }

    public static function login(string $username, string $password): bool {
        $users = self::loadUsers();
        if (!isset($users[$username])) return false;
        if (!password_verify($password, $users[$username])) return false;
        // Check expiry before allowing login
        $meta = self::loadMeta();
        if (isset($meta[$username]['expires_at']) && $meta[$username]['expires_at'] !== null) {
            if (time() > $meta[$username]['expires_at']) return false;
        }
        $_SESSION['portal_user'] = $username;
        $_SESSION['portal_at']   = time();
        // Update last login
        $meta[$username]['last_login'] = time();
        self::saveMeta($meta);
        return true;
    }

    // ── Backup helpers ────────────────────────────────────────────

    /** Returns raw password hashes keyed by username (admin backup only) */
    public static function getAllUsersRaw(): array {
        return self::loadUsers();
    }

    /** Restore a user directly from a backup hash (skips password_hash) */
    public static function restoreUser(string $username, string $hashedPassword): void {
        $users = self::loadUsers();
        $users[$username] = $hashedPassword;
        self::saveUsers($users);
    }

    public static function logout(): void {
        unset($_SESSION['portal_user'], $_SESSION['portal_at'],
              $_SESSION['impersonating'], $_SESSION['impersonating_as']);
    }

    // ── Admin impersonation ──────────────────────────────────────

    public static function impersonate(string $username): bool {
        if (!self::isAdmin()) return false;
        $users = self::loadUsers();
        if (!isset($users[$username])) return false;
        // Store original admin so we can restore
        $_SESSION['impersonating']    = self::currentUser();
        $_SESSION['impersonating_as'] = $username;
        $_SESSION['portal_user']      = $username;
        $_SESSION['portal_at']        = time();
        return true;
    }

    public static function stopImpersonating(): void {
        $original = $_SESSION['impersonating'] ?? null;
        if ($original) {
            $_SESSION['portal_user']      = $original;
            $_SESSION['portal_at']        = time();
            unset($_SESSION['impersonating'], $_SESSION['impersonating_as']);
        }
    }

    public static function isImpersonating(): bool {
        return !empty($_SESSION['impersonating']);
    }

    public static function impersonatingAs(): ?string {
        return $_SESSION['impersonating_as'] ?? null;
    }

    public static function originalAdmin(): ?string {
        return $_SESSION['impersonating'] ?? null;
    }

    public static function currentUser(): ?string {
        return $_SESSION['portal_user'] ?? null;
    }

    /** Alias for isAuthed() — returns bool without redirecting */
    public static function check(): bool {
        return self::isAuthed();
    }

    public static function isAdmin(): bool {
        if (!self::isAuthed()) return false;
        $user   = self::currentUser();
        $admins = defined('ADMIN_USERS') ? ADMIN_USERS : ['admin'];
        return in_array($user, $admins, true);
    }

    public static function guard(string $loginUrl = 'login.php'): void {
        if (!self::isAuthed()) {
            header("Location: {$loginUrl}");
            exit;
        }
    }

    public static function guardAdmin(string $loginUrl = 'login.php'): void {
        if (!self::isAuthed()) {
            header("Location: {$loginUrl}");
            exit;
        }
        if (!self::isAdmin()) {
            http_response_code(403);
            $user = htmlspecialchars(self::currentUser() ?? '');
            echo '<!DOCTYPE html><html><head><title>Access Denied</title>'
               . '<link href="https://fonts.googleapis.com/css2?family=Syne:wght@700&family=DM+Mono&display=swap" rel="stylesheet"/>'
               . '<style>*{margin:0;padding:0;box-sizing:border-box}body{background:#0a0a12;color:#e8e8f0;font-family:Syne,sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh;flex-direction:column;gap:1rem}'
               . '.icon{font-size:3rem}.title{font-size:1.5rem;font-weight:700;color:#e05252}'
               . '.sub{font-size:.85rem;color:#6b6b8a;font-family:"DM Mono",monospace}'
               . 'a{color:#d4a843;font-size:.8rem;border:1px solid #d4a843;padding:.4rem 1rem;border-radius:6px;text-decoration:none;margin-top:.5rem}'
               . 'a:hover{background:rgba(212,168,67,.1)}'
               . '</style></head><body>'
               . '<div class="icon">🔒</div>'
               . '<div class="title">Access Denied</div>'
               . '<div class="sub">Admin access only. Logged in as: <strong>' . $user . '</strong></div>'
               . '<a href="index.php">← Back to Mail</a>'
               . '</body></html>';
            exit;
        }
    }

    // ── User management (called from manage-users.php) ───────────

    public static function getUsers(): array {
        return array_keys(self::loadUsers());
    }

    public static function addUser(string $username, string $password, ?int $durationDays = null): bool {
        $users = self::loadUsers();
        if (isset($users[$username])) return false;
        $users[$username] = password_hash($password, PASSWORD_DEFAULT);
        if (!self::saveUsers($users)) return false;
        // Set metadata
        $meta = self::loadMeta();
        $meta[$username] = [
            'created_at' => time(),
            'expires_at' => $durationDays ? (time() + $durationDays * 86400) : null,
            'duration_days' => $durationDays,
            'last_login' => null,
            'role' => 'user',
        ];
        self::saveMeta($meta);
        return true;
    }

    public static function changePassword(string $username, string $password): bool {
        $users = self::loadUsers();
        if (!isset($users[$username])) return false;
        $users[$username] = password_hash($password, PASSWORD_DEFAULT);
        return self::saveUsers($users);
    }

    public static function setExpiry(string $username, ?int $durationDays): bool {
        $meta = self::loadMeta();
        if (!isset($meta[$username])) $meta[$username] = [];
        $meta[$username]['expires_at']   = $durationDays ? (time() + $durationDays * 86400) : null;
        $meta[$username]['duration_days'] = $durationDays;
        return self::saveMeta($meta);
    }

    public static function removeUser(string $username): bool {
        $users = self::loadUsers();
        if (!isset($users[$username])) return false;
        unset($users[$username]);
        if (!self::saveUsers($users)) return false;
        $meta = self::loadMeta();
        unset($meta[$username]);
        self::saveMeta($meta);
        return true;
    }

    public static function getUsersMeta(): array {
        $users = self::loadUsers();
        $meta  = self::loadMeta();
        $out   = [];
        foreach (array_keys($users) as $u) {
            $m = $meta[$u] ?? [];
            $out[$u] = [
                'username'     => $u,
                'created_at'   => $m['created_at']   ?? null,
                'expires_at'   => $m['expires_at']   ?? null,
                'duration_days'=> $m['duration_days'] ?? null,
                'last_login'   => $m['last_login']   ?? null,
                'role'         => $m['role']         ?? 'user',
                'expired'      => isset($m['expires_at']) && $m['expires_at'] !== null && time() > $m['expires_at'],
            ];
        }
        return $out;
    }
}
