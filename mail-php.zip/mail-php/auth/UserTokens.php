<?php
// Per-user invite token + invite code helpers
// user_tokens.json  → { "username": "raw-token", ... }
// invite_codes.json → { "CODE": { "portal_user": "x", "bg": "docusign", "created_at": 123 }, ... }

// ── User token storage ────────────────────────────────────

function getUserTokensFile(): string {
    return __DIR__ . '/../data/user_tokens.json';
}

function loadUserTokens(): array {
    $f = getUserTokensFile();
    return file_exists($f) ? (json_decode(file_get_contents($f), true) ?? []) : [];
}

function saveUserTokens(array $tokens): void {
    $file = getUserTokensFile();
    $dir  = dirname($file);
    if (!is_dir($dir)) { @mkdir($dir, 0755, true); }
    @file_put_contents($file, json_encode($tokens, JSON_PRETTY_PRINT));
}

function getUserToken(string $username): string {
    return loadUserTokens()[$username] ?? '';
}

function setUserToken(string $username, string $token): void {
    $tokens = loadUserTokens();
    if ($token === '') unset($tokens[$username]);
    else $tokens[$username] = $token;
    saveUserTokens($tokens);
}

function generateUserToken(): string {
    return bin2hex(random_bytes(16)); // 32-char hex
}

// ── Invite code storage ───────────────────────────────────
// Codes are short opaque strings. URL shows only the code — never username/bg/token.

function getInviteCodesFile(): string {
    return __DIR__ . '/../data/invite_codes.json';
}

function loadInviteCodes(): array {
    $f = getInviteCodesFile();
    return file_exists($f) ? (json_decode(file_get_contents($f), true) ?? []) : [];
}

function saveInviteCodes(array $codes): void {
    $file = getInviteCodesFile();
    $dir  = dirname($file);
    if (!is_dir($dir)) { @mkdir($dir, 0755, true); }
    $result = @file_put_contents($file, json_encode($codes, JSON_PRETTY_PRINT));
    if ($result === false) {
        error_log('[UserTokens] Failed to write invite codes file: ' . $file);
    }
}

/**
 * Create (or refresh) an opaque invite code for a portal user + background.
 * $portalUser can be '__global__' for the admin global token (portal_user resolved at sign-in time from session).
 * The same user always gets the same code — regenerate by deleting old one first.
 * Returns the short code string.
 */
function getOrCreateInviteCode(string $portalUser, string $bg = 'docusign'): string {
    $codes = loadInviteCodes();
    // Find existing code for this user (update bg if changed)
    foreach ($codes as $code => $data) {
        if (($data['portal_user'] ?? '') === $portalUser) {
            if ($data['bg'] !== $bg) {
                $codes[$code]['bg'] = $bg;
                saveInviteCodes($codes);
            }
            return $code;
        }
    }
    // Generate new short code: 8 alphanumeric chars
    do {
        $code = substr(str_replace(['+','/','='], '', base64_encode(random_bytes(8))), 0, 8);
    } while (isset($codes[$code]));
    $codes[$code] = [
        'portal_user' => $portalUser,
        'bg'          => $bg,
        'created_at'  => time(),
    ];
    saveInviteCodes($codes);
    return $code;
}

/**
 * Regenerate (rotate) the invite code for a portal user.
 * Old code is deleted; a new one is issued.
 */
function regenerateInviteCode(string $portalUser, string $bg = 'docusign'): string {
    $codes = loadInviteCodes();
    // Remove existing code for this user
    foreach ($codes as $code => $data) {
        if (($data['portal_user'] ?? '') === $portalUser) {
            unset($codes[$code]);
            break;
        }
    }
    saveInviteCodes($codes);
    return getOrCreateInviteCode($portalUser, $bg);
}

/**
 * Resolve an opaque invite code → ['portal_user' => '...', 'bg' => '...'] or null.
 * Reusable: codes never expire unless explicitly rotated.
 * If portal_user is '__global__', the caller (inviteapi.php) should bind to $_SESSION['portal_user'].
 */
function resolveInviteCode(string $code): ?array {
    if (!$code) return null;
    $codes = loadInviteCodes();
    return $codes[$code] ?? null;
}

/**
 * Update the bg stored with a code.
 */
function updateInviteCodeBg(string $portalUser, string $bg): void {
    $codes = loadInviteCodes();
    foreach ($codes as $code => &$data) {
        if (($data['portal_user'] ?? '') === $portalUser) {
            $data['bg'] = $bg;
            break;
        }
    }
    unset($data);
    saveInviteCodes($codes);
}

// ── Token validation (kept for inviteapi.php compatibility) ──

function validateInviteToken(string $token): ?string {
    if (!$token) return null;
    $global = defined('INVITE_TOKEN') ? INVITE_TOKEN : '';
    if ($global && $token === $global) return '__global__';
    $tokens = loadUserTokens();
    foreach ($tokens as $username => $userToken) {
        if ($userToken && $token === $userToken) return $username;
    }
    return null;
}


// ── Per-user AI settings helpers ─────────────────────────────────

function getUserAiSettingsFile(string $username): string {
    return __DIR__ . '/../data/ai_settings_' . preg_replace('/[^a-zA-Z0-9_-]/', '_', $username) . '.json';
}

function loadUserAiSettings(string $username): array {
    $f = getUserAiSettingsFile($username);
    return file_exists($f) ? (json_decode(file_get_contents($f), true) ?? []) : [];
}

function saveUserAiSettings(string $username, array $settings): bool {
    return (bool) file_put_contents(
        getUserAiSettingsFile($username),
        json_encode($settings, JSON_PRETTY_PRINT)
    );
}

/**
 * Resolve AI settings for a user:
 * - use their personal key/model if set
 * - fall back to global ai_settings.json
 */
function resolveAiSettings(string $username): array {
    $personal = loadUserAiSettings($username);
    if (!empty($personal['openrouter_api_key'])) {
        return $personal;
    }
    // Fall back to global
    $globalFile = __DIR__ . '/../data/ai_settings.json';
    $global = file_exists($globalFile) ? (json_decode(file_get_contents($globalFile), true) ?? []) : [];
    return $global;
}
